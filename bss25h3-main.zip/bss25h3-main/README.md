# sweb
[![Build Status](https://travis-ci.org/IAIK/sweb.svg?branch=main)](https://travis-ci.org/IAIK/sweb)

SWEB Educational OS

Please have a look at https://www.iaik.tugraz.at/os
