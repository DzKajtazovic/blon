#include "atkbd.h"

struct KMI* kmi = (struct KMI*)0x18000000;

bool kbdBufferFull()
{
  struct KMI* kmi = (struct KMI*)0x18000000;
  return kmi->stat & 0x10;
}

uint8 kbdGetScancode()
{
  return kmi->data;
}

