#pragma once

// DO NOT CHANGE THE NAME OR THE TYPE OF THE user_progs VARIABLE!
char const *user_progs[] = {
// for reasons of automated testing
                            "/usr/shell.sweb",
                            0
                           };

