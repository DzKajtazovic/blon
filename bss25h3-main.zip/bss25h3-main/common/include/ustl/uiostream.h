#pragma once

#include "sostream.h"
#include "mistream.h"
#include "outerrstream.h"

namespace ustl
{

   extern coutclass& cout;
   extern coutclass& cerr;

}
