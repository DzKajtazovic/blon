All files in this folder (userspace/data) are copied to the SWEB minix partition.

