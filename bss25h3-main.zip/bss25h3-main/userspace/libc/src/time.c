#include "time.h"


/**
 * function stub
 * posix compatible signature - do not change the signature!
 */
clock_t clock(void)
{
  return (clock_t) -1U;
}
